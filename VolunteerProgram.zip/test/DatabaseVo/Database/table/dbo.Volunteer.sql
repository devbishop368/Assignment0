﻿CREATE TABLE [dbo].[Volunteer] (
    [ID]          INT       NOT NULL,
    [FName]       CHAR (55) NULL,
    [LName]       CHAR (55) NULL,
    [Opportunity] CHAR (55) NULL,
    [Filter] CHAR(55) NULL, 
    PRIMARY KEY CLUSTERED ([ID] ASC)
);


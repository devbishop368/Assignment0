﻿CREATE TABLE [dbo].[Opportunities]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(55) NULL, 
    [Description] VARCHAR(255) NULL, 
    [City] VARCHAR(50) NULL, 
    [Date] DATETIME2 NULL, 
    [Keyword] VARCHAR(50) NULL
)

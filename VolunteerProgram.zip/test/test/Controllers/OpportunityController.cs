﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using test.Models;

namespace test.Controllers
{
    public class OpportunityController : Controller
    {
        private OpportunityIDRepository repository;

        public OpportunityController(OpportunityIDRepository repo)
        {
            repository = repo;
        }
        //view all the volunteer
        [HttpGet]
        public ViewResult OppList()
        {
            ViewBag.name = null;
            return View(repository.Opportunities);
        }

        [HttpPost]
        //view the list of volunteer
        public ViewResult OppList(string Name)
        {

            ViewBag.name = Name;

            return View(repository.Opportunities);

        }


        public ViewResult OppInfo(int Id) => View(repository.Opportunities.FirstOrDefault(p => p.ID == Id));


        //save opporunity
        [HttpPost]
        public IActionResult Oppinfo(Opportunity opportunity)
        {
            if (ModelState.IsValid)
            {
                repository.SaveOpportunity(opportunity);

                return RedirectToAction("Opplist");
            }
            else
            {
                return View(opportunity);
            }
        }
        public ViewResult Create() => View("OppInfo", new Opportunity());

        //delete opporunity
        public IActionResult Delete(int ID)
        {
            Opportunity deleteOpportunity = repository.DeleteOpportunity(ID);


            return RedirectToAction("Opplist");


        }

    }
}
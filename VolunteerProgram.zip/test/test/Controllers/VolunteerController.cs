﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using test.Models;

namespace test.Controllers
{
    public class VolunteerController : Controller
    {
        private VolunteerIDRepository repository;

        public VolunteerController(VolunteerIDRepository repo)
        {
            repository = repo;
        }

        //view all the volunteer
        [HttpGet]
        public ViewResult List()
        {
            ViewBag.name = null;
            return View(repository.Volunteer);
        } 

        [HttpPost]
       //view the list of volunteer
        public ViewResult List(string Name) {

            ViewBag.name = Name;

            return View(repository.Volunteer);

        }


        //[HttpGet]
        //public ViewResult Voluinfo(string name)
        //{

        //    ViewBag.name = name;
        //    return View();
        //}
        //[HttpPost]
        //public ViewResult Voluinfo(Volunteer volu)
        //{


        //    return View("voluinfo", volu);
        //}


        //display volunteer
        public ViewResult Voluinfo(int Id) => View(repository.Volunteer.FirstOrDefault(p => p.ID == Id));

        //save volunteer
        [HttpPost]
        public IActionResult Voluinfo(Volunteer volunteer)
        {
            if (ModelState.IsValid)
            {
                repository.SaveVolunteer(volunteer);

                return RedirectToAction("list"); }
            else
            {                
                return View(volunteer);
            }
        }
        //create volunteer
        public ViewResult Create() => View("Voluinfo", new Volunteer());

      //delete volunteer
        public IActionResult Delete(int ID)
        {
            Volunteer deleteVolunteer = repository.DeleteVolunteer(ID);

      
            return RedirectToAction("list");


        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
namespace test.Models
{
    public class ApplicationDbContext :DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : 
            base(options) { }


        public DbSet<Opportunity> Opportunities
        {
            get;set;
        }
        public DbSet<Volunteer> Volunteer
        {
            get; set;
        }
    }
}

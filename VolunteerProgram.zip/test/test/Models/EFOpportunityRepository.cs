﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class EFOpportunityRepository : OpportunityIDRepository
    {
        private ApplicationDbContext context;
        public EFOpportunityRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IEnumerable<Opportunity> Opportunities => context.Opportunities;

        //add or update opportunity
        public void SaveOpportunity(Opportunity opportunity)
        {
            if (opportunity.ID != 0)
            {
                Opportunity dbEntry = context.Opportunities
                    .FirstOrDefault(p => p.ID ==opportunity.ID);

                if (dbEntry == null)
                {
                    context.Opportunities.Add(opportunity);
                }
                else if (dbEntry != null)
                {
                    dbEntry.Name = opportunity.Name;
                    dbEntry.City = opportunity.City;
                    dbEntry.Description = opportunity.Description;
                    dbEntry.Keyword = opportunity.Keyword;
                    dbEntry.Date = opportunity.Date;

                }

            }


            context.SaveChanges();

        }
        //Delete opportunity
        public Opportunity DeleteOpportunity(int ID)
        {
            Opportunity dbEntry = context.Opportunities
                .FirstOrDefault(p => p.ID == ID);

            if (dbEntry != null)
            {
                context.Opportunities.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;

        }

    }
}

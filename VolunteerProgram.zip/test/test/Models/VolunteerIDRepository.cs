﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public interface VolunteerIDRepository
    {
            IEnumerable<Volunteer> Volunteer { get; }

            void SaveVolunteer(Volunteer volunteer);

            Volunteer DeleteVolunteer(int ID);
    }
}

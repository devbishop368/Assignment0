﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class Volunteer
    {
        private VolunterContext context;
        
        public int ID { get; set; }
        public string FName { get; set; }
        public string LName { get; set; }

        public string Opportunity { get; set; }

        public string Status { get; set; }
        public string State { get; set; }
        public string City { get; set; }
        public string Zip { get; set; }
        public string Street { get; set; }

        public string CellPhone { get; set; }
        public string Email { get; set; }
        public string EmCell { get; set; }
        public string EmContact { get; set; }

        public string  EmEmail{ get; set; }
        public string EmStreet  { get; set; }
        public string EmCity  { get; set; }
        public string EmZip { get; set; }
        public string EmState { get; set; }
        public string DriverLicense { get; set; }
        public string SSC { get; set; }



    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class FakeIDRepository 
    {


        public IEnumerable<Volunteer> Volunteers => new List<Volunteer> {

            // new Volunteer {  FirtName ="john", LastName = "william", Opp="baby kitten" },
            //new Volunteer {  FirtName ="Boby", LastName = "william", Opp="baby kitten"},
            //new Volunteer {  FirtName ="billy", LastName = "bob", Opp="baby shark" },
            //new Volunteer {  FirtName ="Boby", LastName = "william", Opp="baby kitten"},
            //new Volunteer {  FirtName ="weesy", LastName = "sam", Opp="baby froto" },
            //new Volunteer {  FirtName ="same", LastName = "billm", Opp="baby kitten"},
            //new Volunteer {  FirtName ="froto", LastName = "william", Opp="baby dog" },
            //new Volunteer {  FirtName ="mary", LastName = "fortoam", Opp="baby kitten"},
            //new Volunteer {  FirtName ="jac", LastName = "william", Opp="baby dog" },
            //new Volunteer {  FirtName ="By", LastName = "wadam", Opp="baby tiger"}
         };
    }
}

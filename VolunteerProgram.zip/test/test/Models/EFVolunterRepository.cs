﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace test.Models
{
    public class EFVolunterRepository :VolunteerIDRepository
    {
        private ApplicationDbContext context;
        public EFVolunterRepository(ApplicationDbContext ctx)
        {
            context = ctx;
        }
        public IEnumerable<Volunteer> Volunteer => context.Volunteer;

        //add or update volunteer
        public void SaveVolunteer(Volunteer volunteer)
        {
            if (volunteer.ID != 0)
            {
                Volunteer dbEntry = context.Volunteer
                    .FirstOrDefault(p => p.ID == volunteer.ID);

                if (dbEntry == null)
                {
                    context.Volunteer.Add(volunteer);   
                }
                else if (dbEntry != null)
                {
   
                    dbEntry.FName = volunteer.FName;
                    dbEntry.LName = volunteer.LName;
                    dbEntry.Opportunity = volunteer.Opportunity;
                    dbEntry.Status = volunteer.Status;

                }
               
            }
      

             context.SaveChanges(); 
           
        }
    //Delete volunteer
        public Volunteer DeleteVolunteer(int ID)
        {
            Volunteer dbEntry = context.Volunteer
                .FirstOrDefault(p => p.ID == ID);

            if (dbEntry != null)
            {
                context.Volunteer.Remove(dbEntry);
                context.SaveChanges();
            }
            return dbEntry;

        }

    }
} 
 

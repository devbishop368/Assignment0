﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using test.Models;
using MySql.Data.MySqlClient;

using Microsoft.EntityFrameworkCore;
namespace test
{
    public class Startup
    {

        IConfigurationRoot Configuration;
        public Startup(IHostingEnvironment env)
        {
            Configuration = new ConfigurationBuilder()
                .SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json").Build();
        }
        public void ConfigureServices(IServiceCollection services)
        {
            //services.AddTransient<VolunteerIDRepository, FakeIDRepository>();

            services.AddDbContext<ApplicationDbContext>(options =>
            options.UseSqlServer(Configuration.GetConnectionString("DefaultConnection")));
            services.AddTransient<VolunteerIDRepository, EFVolunterRepository>(); services.AddMvc();
            services.AddTransient<OpportunityIDRepository, EFOpportunityRepository>(); services.AddMvc();
            services.AddMvc();
        }
        public void Configure(IApplicationBuilder app, IHostingEnvironment env, ILoggerFactory
            loggerFactory)
        {

            //loggerFactory.AddConsole(Configuration.GetSection("Logging"));
            //loggerFactory.AddDebug();

            app.UseDeveloperExceptionPage();
            app.UseStatusCodePages();
            app.UseStaticFiles();
            app.UseMvc(routes => {

                routes.MapRoute(
                    name: "admin",
                     template: "/admin/login",
                    defaults: new { Controller = "Admin", action = "AdminLogin" }
                    );

                routes.MapRoute(
                    name: "list",
                    template: "/volunteer/list",
                    defaults: new { Controller = "Volunteer", action = "List" }
                     );


                routes.MapRoute(
                    name: "default",
                    template: "{controller=Admin}/{action=AdminLogin}/{id?}");

            });
        }
    }

}
